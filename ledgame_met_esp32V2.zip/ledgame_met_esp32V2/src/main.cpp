#include <Arduino.h>
#include <WiFi.h>
#include <FastLED.h>
#include <stdlib.h>
#include <HTTPClient.h>
#include <LiquidCrystal_I2C.h>

//joystick declaratie
#define DATA_PIN 21                           //aansluit pin van de data van de ledstrip
#define CLOCK_PIN 5                           //aansluit pin van de clock van de ledstrip
#define BOVEN 26                              //aansluit pin van de naar boven van de joystick
#define ONDER 34                              //aansluit pin van de naar onder van de joystick
#define START 25                              //aansluit pin van de start van het spel

unsigned long LaatsteDrukTijd;                //een unsigned long met de laatstedruktijd

bool rainbowActive = false;                   //rainboweffect op false
uint8_t gHue = 0;                             //rainbow gelijk aan 0

//drukknop declaratie
#define BUTTON1_PIN 13                        //aansluit pin drukknop 1
#define BUTTON2_PIN 27                        //aansluit pin drukknop 2

#define PLAYER1_COLOR CRGB::Red               //game 2 speler 1 kleur
#define PLAYER2_COLOR CRGB::Blue              //game 2 speler 2 kleur
#define BACKGROUND_COLOR CRGB::Black          //game 2 achtergrond kleur

bool LastButtonPress1 = HIGH;                 //laatste drukknop 1 op hoog
bool LastButtonPress2 = HIGH;                 //laatste drukknop 2 op hoog

unsigned long debounceTime = 100;             //debounce tijd van 100ms voor de drukknoppen
unsigned long Tijd1;                          //een unsigned long Tijd1
unsigned long Tijd2;                          //een unsigned long Tijd2

bool gameOver = false;                        //bool gameover op false

const char* ssid = "I115";                  //wifi netwerk naam
const char* password = "vivesiot";          //wifi wachtwoord


WiFiServer server(80);

String header;
int NUM_LEDS = 63;                            //het totaal aantal leds van de ledstrip
CRGB leds[200];                               //het totaal aantal leds in de bibliotheek FastLED

int pos1 = 0;                                 //positie 1 van game 2
int pos2 = NUM_LEDS / 2;                      //positie 2 van game 2

int gameSelect = 1;
int score;                                    //variabele score om de score bij te houden
int rodePositie = 0;                          //variabele met de rode positie ingesteld op 0
int groenePositie = random(1,10);

String uitgang21Staat = "off";
String uitgang14Staat = "off";

const int uitgang21 = 21;
const int uitgang14 = 14;
unsigned long huidigeTijd1 = 0;

unsigned long huidigeTijd = 0;
unsigned long vorigeTijd = 0;
const long timeOutTijd = 100;
unsigned long gameTijd = 30000;               //variabele gameTijd met de tijd dat een spel duurt
bool spelBezig = false;  

void updateLeds();                            //initialisatie updateLeds
void winEffect();                             //initialisatie winEffect
void genereerNieuwGroenePositie();            //initialisatie genereerNieuwGroenePositie
void verliesEffect();                         //initialisatie verliesEffect
void resetGame();                             //initialisatie resetGame
void startGame();                             //initialisatie startGame
void Score();

LiquidCrystal_I2C lcd(0x27, 16,2);

void setup() {
  // put your setup code here, to run once:

  lcd.init();
  lcd.backlight();
  Serial.begin(115200);
  pinMode(uitgang21, OUTPUT);
  pinMode(uitgang14, OUTPUT);
  digitalWrite(uitgang21, LOW);
  digitalWrite(uitgang14, LOW);

  Serial.print("Connecting to ");
  Serial.println(ssid);
  WiFi.begin(ssid, password);
  while(WiFi.status() != WL_CONNECTED){
    delay(500);
    Serial.print(".");
    lcd.print(".");
  }

  Serial.println("");
  Serial.println("Wifi connected.");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("SSID:");
  lcd.setCursor(6,0);
  lcd.print(ssid);
  lcd.setCursor(0,1);
  lcd.print(WiFi.localIP());
  
  server.begin();

  FastLED.addLeds<APA102, DATA_PIN, CLOCK_PIN, BGR>(leds, NUM_LEDS);
  FastLED.setBrightness(100); 
  pinMode(BOVEN, INPUT_PULLUP);                                         //pinmode van de joystick naar boven
  pinMode(ONDER, INPUT_PULLUP);                                         //pinmode van de joystick naar onder
  pinMode(START, INPUT_PULLUP);                                         //pinmode van de start drukknop
  randomSeed(analogRead(0));                                            //
  updateLeds();
  FastLED.clear();

  pinMode(BUTTON1_PIN, INPUT_PULLUP);
  pinMode(BUTTON2_PIN, INPUT_PULLUP);

}

void loop() {
  // put your main code here, to run repeatedly:

  WiFiClient client = server.available();

  if(client){
    huidigeTijd = millis();
    vorigeTijd = huidigeTijd;
    Serial.println("Nieuwe gebruiker.");
    String huidigeLijn = "";
    while(client.connected() && huidigeTijd - vorigeTijd <= timeOutTijd){
      huidigeTijd = millis();
      if(client.available()){
        char c = client.read();
        Serial.write(c);
        header += c;
        if(c == '\n'){
          if(huidigeLijn.length() == 0){
            client.println("HTTP/1.1 200 OK");
            client.println("Content-type:text/html");
            client.println("Connection: close");
            client.println();

            //verwerk tekstinvoer
            if(header.indexOf("GET /set?num=") >= 0){
              int start = header.indexOf("num=") + 4;
              int end = header.indexOf("&", start);
              if(end == -1) end = header.indexOf(" ", start);
              if(end == -1) end = header.length();
              String numStr = header.substring(start, end);
              NUM_LEDS = numStr.toInt();
              Serial.print("NUM_LEDS is ingesteld op: ");
              Serial.println(NUM_LEDS);

              fill_solid(leds, 200, CRGB::Black);
              FastLED.show();

              FastLED.clear();
              FastLED.addLeds<APA102, DATA_PIN, CLOCK_PIN, BGR>(leds, NUM_LEDS);
              FastLED.show();
            } 
            else if (header.indexOf("GET /set?score=") >= 0){
              int start = header.indexOf("score=") + 6;
              int end = header.indexOf("&", start);
              if(end == -1) end = header.indexOf(" ",start);
              if(end == -1) end = header.length();
              String scoreStr = header.substring(start, end);
              score = scoreStr.toInt();
              Serial.print("Score is ingesteld op: ");
              Serial.println(score);
            }
            else if(header.indexOf("GET /set?num1=") >= 0){
              int start = header.indexOf("num1=") + 5;
              int end = header.indexOf("&", start);
              if(end == -1) end = header.indexOf(" ", start);
              if(end == -1) end = header.length();
              String GameTijd = header.substring(start,end);
              gameTijd = GameTijd.toInt();
              Serial.print("Game Tijd is ingesteld op: ");
              Serial.println(gameTijd);

              FastLED.clear();
              FastLED.addLeds<APA102, DATA_PIN, CLOCK_PIN, BGR>(leds, NUM_LEDS);
              FastLED.show();
            }
            else if(header.indexOf("GET /set?game=") >= 0){
              int start = header.indexOf("game=") + 5;
              int end = header.indexOf("&", start);
              if(end == -1) end = header.indexOf(" ",start);
              if(end == -1) end = header.length();
              String gameStr = header.substring(start, end);
              gameSelect = gameStr.toInt();
              Serial.print("Game geselecteerd: ");
              Serial.println(gameSelect);
            }

            //HTML-pagina met tekstvak en knoppen
            client.println("<!DOCTYPE html><html><head><meta name='vieuwport' content='width=device-width, initial-scale=1'>");             
            client.println("<style>body { font-family: Arial; text-align: center; } </style><head><body>");

            client.println("<h1>LED-strip game</h1>");                                                                                        //plaatst de eerste hoofding op de webpagina
            client.println("<h2> Aanpassingen </h2>");                                                                                        //plaatst een tweede hoofding op de webpagina

            client.println("<p>Huidige aantal leds: " + String(NUM_LEDS) + "</p>");                                                           //plaatst een lijn op de webpagina met info over het aantal leds
            client.println("<form action='/set' method='GET'>");                                                                              //een form met een GET om de waarde van de leds in te stellen
            client.println("<input type='number' name='num' min='10' max='63' required value='" + String(NUM_LEDS) + "'>");                   //box om de waarde van de aantal leds in te vullen
            client.println("<input type='submit' value='Update'>");                                                                           //knop om de waarde van het aantal leds te updaten
            client.println("</form>");                                                                                                        //form sluiten

            client.println("<p>Huidige Game Tijd: " + String(gameTijd) + "</p>");                                                             //plaatst een lijn op de webpagina met info over de gametijd
            client.println("<form action='/set' method='GET'>");                                                                              //een form met een GET om de waarde van de gametijd aan te passen
            client.println("<input type='number' name='num1' min='5000' max='60000' required value='" + String(gameTijd) + "'>");             //box om de waarde van de gametijd in te vullen
            client.println("<input type='submit' value='Update'>");                                                                           //knop om de waarde van de gametijd te updaten
            client.println("</form>");                                                                                                        //form sluiten

            client.println("<p>Selecteer spel:</p>");
            client.println("<form action='/set' method='GET'>");
            client.println("<select name='game'>");
            client.println("<option value='1'" + String(gameSelect == 1 ? " selected" : "") + ">Game 1 - Joystick</option>");
            client.println("<option value='2'" + String(gameSelect == 2 ? " selected" : "") + ">Game 2 - Drukknop</option>");
            client.println("</select>");
            client.println("<input type='submit' value='Start Game'>");
            client.println("</form>");

            client.println("<h3> spel statistieken </h3>");                                                                                   //plaats een derde hoofding op de webpagina
            client.println("<p> score =  " + String(score) + "</p>");                                                                         //plaatst een lijn op de webpagina met info over de score

            client.println("</body></html>");
            client.println();
            break;
          } else{
            huidigeLijn = "";
          }
        } else if(c != '\r'){
          huidigeLijn += c;
        }
      }
    }
    header = "";
    client.stop();
    Serial.println("Client disconnected.");
    Serial.println("");
  }

                                                         
    if(gameSelect == 1){
      FastLED.clear();
      if(digitalRead(BUTTON1_PIN) == LOW && !spelBezig){                          //als de start drukknop word in gedrukt en het spel is niet bezig
        startGame(); 
        huidigeTijd1 = millis();
        LaatsteDrukTijd = millis();
        groenePositie = random(1,10);
      }
      Serial.print("Game 1");
      if(spelBezig && (millis() - huidigeTijd > gameTijd)){                   //als het spel bezig is en millis - startTijd is groter dan de gameTijd
        verliesEffect();                                                    //verliesEffect weergeven op leds
        WiFiClient client;
        if(client.connect(WiFi.localIP(),80)){
          String url = "/";
          client.println("GET " + url + " HTTP/1.1");
          client.println("Host: " + WiFi.localIP().toString());
          client.println("Connection: close");
          client.println();
          Serial.println("Hoofdpagina bijgewerkt met score: " + String(score));
          client.println("<p> score =  " + String(score) + "</p>");
        }
        else{
          Serial.println("Fout bij verzenden score.");
        }
        Score();                                                            //Score weergeven op leds
        delay(10000);                                                       //tijd dat de score wordt weergegeven op de leds
        resetGame();                                                        //het spel resetten om opnieuw te beginnen
      }

      if(spelBezig){                                                        //als het spel bezig is
        if(digitalRead(ONDER) == LOW && rodePositie > 0){                   //als de joystick naar beneden is en de rode positie is meer dan 0
          rodePositie--;                                                    //rode positie met 1 verminderen
          updateLeds();                                                     //nieuwe staat van de leds naar de leds schrijven
          LaatsteDrukTijd = millis();
          Serial.println(LaatsteDrukTijd);
          delay(50);                                                        //vertraging van 50ms
        }
        else if(digitalRead(BOVEN) == LOW && rodePositie < NUM_LEDS){       //als de joystick naar boven is en de rode positie is kleiner dan het maximale aantal leds
          rodePositie++;                                                    //rode positie met 1 verhogen
          updateLeds();                                                     //nieuwe staat van de leds naar de leds schrijven
          LaatsteDrukTijd = millis();
          Serial.println(LaatsteDrukTijd);
          delay(50);                                                        //vertraging van 50ms
        }
        if(rodePositie == groenePositie){                                   //als de rode positie gelijk is aan de groene positie
          winEffect();                                                      //winEffect
          score++;                                                          //score met 1 verhogen
          genereerNieuwGroenePositie();                                     //genereer een nieuwe groene positie
          updateLeds();                                                     //nieuwe staat van de leds op de leds weergeven
        }
      }
    }
    else if(gameSelect == 2){
      FastLED.clear();
      if(digitalRead(BUTTON1_PIN) == LOW && !spelBezig){                          //als de start drukknop word in gedrukt en het spel is niet bezig
        startGame();
        LaatsteDrukTijd = millis();
        Serial.println(LaatsteDrukTijd); 
      }
      Serial.print("Game 2");
      if(gameOver){
        gameOver = false;
        spelBezig = false;
        pos1 = 0;
        pos2 = NUM_LEDS/2;
      }

      bool ingedrukt1 = digitalRead(BUTTON1_PIN);
      bool ingedrukt2 = digitalRead(BUTTON2_PIN);
      if(ingedrukt1 == LOW){
        Tijd1 = millis();
      }
      if(ingedrukt2 == LOW){
        Tijd2 = millis();
      }

      unsigned long now = millis();

      if(LastButtonPress1 == HIGH && ingedrukt1 == LOW && now - Tijd1 < 10){
        leds[pos1] = BACKGROUND_COLOR;
        pos1 = (pos1 + 1) % NUM_LEDS;
        LaatsteDrukTijd = millis();
        Serial.println(LaatsteDrukTijd);

        if(pos1 == pos2){
          Serial.println("Speler 1 heeft Speler 2 ingehaald! Speler 1 wint!");
          lcd.clear();
          lcd.setCursor(0,0);
          lcd.print("speler links");
          lcd.setCursor(0,1);
          lcd.print("wint");
          delay(5000);
          gameOver = true;
        }
      }
      if(LastButtonPress2 == HIGH && ingedrukt2 == LOW && now - Tijd2 < 10){
        leds[pos2] = BACKGROUND_COLOR;
        pos2 = (pos2 + 1) % NUM_LEDS;
        LaatsteDrukTijd = millis();
        Serial.println(LaatsteDrukTijd);

        if(pos2 == pos1){
          Serial.println("Speler2 heeft speler 1 ingehaald! Speler 2 wint!");
          lcd.clear();
          lcd.setCursor(0,0);
          lcd.print("speler rechts");
          lcd.setCursor(0,1);
          lcd.print("wint");
          delay(5000);
          gameOver = true;
        }
      }

      leds[pos1] = PLAYER1_COLOR;
      leds[pos2] = PLAYER2_COLOR;

      FastLED.show();

      LastButtonPress1 = ingedrukt1;
      LastButtonPress2 = ingedrukt2;

      delay(10);
    }
    if (!spelBezig && !gameOver && (millis() - LaatsteDrukTijd >= 30000) && !rainbowActive) {
      rainbowActive = true;
      Serial.println("Rainbow idle mode gestart");
      Serial.println(LaatsteDrukTijd);
    }

    if((millis() - LaatsteDrukTijd < 30000) && rainbowActive){
      rainbowActive = false;
      Serial.println("Rainbow idle mode gestopt");
    }

    if (rainbowActive) {
      fill_rainbow(leds, NUM_LEDS, gHue++, 7); // Regenboogkleur met variatie
      FastLED.show();
      delay(20); // vloeiend effect
      if(BUTTON2_PIN == LOW){
      lcd.clear();
      lcd.setCursor(0,0);
      lcd.print("SSID:");
      lcd.setCursor(6,0);
      lcd.print(ssid);
      lcd.setCursor(0,1);
      lcd.print(WiFi.localIP());
    }
    }
}

void updateLeds(){                                                //methode updatLeds
  FastLED.clear();                                                //alle leds uit
  leds[groenePositie] = CRGB :: Green;                            //led op de groene positie op groen
  leds[rodePositie] = CRGB :: Red;                                //led op de rode positie op rood
  FastLED.show();                                                 //ledstatus weergeven op de leds
}

void genereerNieuwGroenePositie(){                                //methode genereerNieuweGroenePositie
  do{                                                             //doe
    groenePositie = random(0,NUM_LEDS);                           //groene positie een nieuwe waarde geven
  }while(groenePositie == rodePositie);                           //tijdens dat de groenepositie gelijk is aan de rode positie
}

void winEffect(){                                                 //methode winEffect
  for(int i = 0; i < 5 ; i++){                                    //for lus die 5 maal herhaald wordt
    FastLED.clear();                                              //alle leds uit
    FastLED.show();                                               //ledstatus tonen op leds
    delay(100);                                                   //vertraging van 100ms
    leds[rodePositie] = CRGB :: White;                            //de led op de rode positie word wit
    FastLED.show();                                               //geef de nieuwe ledstatus weer op de leds
    delay(100);                                                   //vertraging van 100ms
  }
} 

void verliesEffect(){                                             //methode verliesEffect
  for(int i = 0; i < 5; i++){                                     //for lus die 5 maal herhaald wordt
    FastLED.clear();                                              //alle leds uit
    FastLED.show();                                               //ledstatus tonen op leds
    delay(100);                                                   //vertraging van 100ms
    fill_solid(leds,NUM_LEDS,CRGB :: Red);                        //volledige ledstrip rood kleuren
    FastLED.show();                                               //geef de nieuwe ledsatus weer op de leds
    delay(100);                                                   //vertraging van 100ms
  }
}

void resetGame(){                                                 //methode resetGame
  rodePositie = 0;                                                //rode positie op 0 plaatsen
  genereerNieuwGroenePositie();                                   //genereer een nieuwe groene positie
  spelBezig = false;                                              //het spel op false zetten zodat het spel niet meer bezig is
  FastLED.clear();                                                //ledstrip volledig uitzetten
  leds[NUM_LEDS] = CRGB :: Green;                                 //
  FastLED.show();                                                 //de nieuwe ledstatus van de leds weergeven op de ledstrip
  score = 0;                                                      //score terug op 0 zetten
  huidigeTijd1 = 0;
}

void startGame(){                                                 //methode startGame
  spelBezig = true;                                               //spel bezig op true zetten 
  huidigeTijd = millis();                                         //startTijd instellen
  updateLeds();                                                   //nieuwe staat van de leds op ledstrip weergeven
}

void Score(){                                                     //methode score
  FastLED.clear();                                                //ledstrip volledig uitzetten
  fill_solid(leds, score, CRGB :: Green);                         //de hoeveelheid leds groen laten oplichten gelijk aan de score
  FastLED.show();                                                 //nieuwe staat van de leds op de ledstrip weergeven
}